import boto3
import os
import logging
from botocore.exceptions import NoCredentialsError, ClientError

# Load AWS credentials and configuration from environment variables
AWS_ACCESS_KEY_ID = os.getenv('AWS_ACCESS_KEY_ID')
AWS_SECRET_ACCESS_KEY = os.getenv('AWS_SECRET_ACCESS_KEY')
AWS_BUCKET_NAME = os.getenv('AWS_BUCKET_NAME')  # Ensure this is globally defined and accessible
AWS_REGION = os.getenv('AWS_REGION', 'us-east-1')  # Default to 'us-east-1' if not set

# Initialize the S3 client with the credentials and region
s3 = boto3.client(
    's3',
    region_name=AWS_REGION,
    aws_access_key_id=AWS_ACCESS_KEY_ID,
    aws_secret_access_key=AWS_SECRET_ACCESS_KEY
)

# Function to upload files to S3 and return presigned URLs
def upload_to_s3(directory, track_name):
    try:
        s3_urls = {}

        # Walk through the directory to find files
        for root, dirs, files in os.walk(directory):
            for file in files:
                file_path = os.path.join(root, file)
                
                # Normalize the file path to ensure it works across OSes and with S3 keys
                s3_key = f"stems/{track_name}/{file}".replace("\\", "/")
                
                # Upload the file to S3
                s3.upload_file(file_path, AWS_BUCKET_NAME, s3_key)
                
                # Generate a presigned URL for the uploaded file (expires in 1 hour)
                s3_urls[file] = s3.generate_presigned_url(
                    'get_object',
                    Params={'Bucket': AWS_BUCKET_NAME, 'Key': s3_key},
                    ExpiresIn=3600
                )
        
        logging.info(f"Uploaded files to S3 for track: {track_name}")
        return s3_urls

    except NoCredentialsError:
        logging.error("AWS credentials not available.")
        return {}
    except ClientError as e:
        logging.error(f"Failed to upload to S3: {e}")
        return {}
    except Exception as e:
        logging.error(f"An unexpected error occurred: {e}")
        return {}
