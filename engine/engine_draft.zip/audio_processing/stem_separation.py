# File: engine/audio_processing/stem_separation.py
import os
import subprocess
import logging
import sys

def separate_audio_with_demucs(file_path, stems_to_process, output_dir):
    abs_file_path = os.path.abspath(file_path)

    # Use the Python executable to run Demucs
    python_executable = sys.executable

    command = [
        python_executable,
        "-u",  # Unbuffered stdout and stderr
        "-m", "demucs",
        abs_file_path,
        "-o", output_dir,
        "-n", "mdx_extra_q",
        "--filename", "{stem}.{ext}",
        "--two-stems", stems_to_process
    ]

    logging.info(f"Running Demucs command: {' '.join(command)}")

    try:
        process = subprocess.Popen(
            command,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            bufsize=1,
            text=True
        )

        # Log Demucs process output
        for line in process.stdout:
            logging.info(f"Demucs: {line.strip()}")

        process.stdout.close()
        process.wait()

        if process.returncode != 0:
            raise Exception(f"Demucs failed with return code {process.returncode}")

        logging.info(f"Demucs completed successfully for {file_path}")

        return process

    except Exception as e:
        logging.error(f"Error during Demucs execution: {e}")
        raise
