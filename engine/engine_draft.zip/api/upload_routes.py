  
# File: engine/api/upload_routes.py
from flask import Blueprint, request, jsonify
from werkzeug.utils import secure_filename
from utils.validators import allowed_file, validate_file_size
import os
import logging

UPLOAD_FOLDER = './uploads'
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

upload_blueprint = Blueprint('upload', __name__)

@upload_blueprint.route('/api/upload-audio', methods=['POST'])
def upload_audio():
    if 'file' not in request.files:
        logging.error('No file part in the request')
        return jsonify({"error": "No file provided"}), 400

    file = request.files['file']
    if file.filename == '':
        logging.error('No file selected')
        return jsonify({"error": "No file selected"}), 400

    if not allowed_file(file.filename):
        logging.error(f'File format not allowed: {file.filename}')
        return jsonify({"error": "Invalid file format. Allowed formats are mp3, wav, flac, ogg, aac."}), 400

    if not validate_file_size(file):
        logging.error(f'File too large: {file.filename}')
        return jsonify({"error": f"File exceeds the size limit of 50MB."}), 400

    filename = secure_filename(file.filename)
    file_path = os.path.join(UPLOAD_FOLDER, filename)
    file.save(file_path)
    logging.info(f'File saved at {file_path}')

    # After saving the file, trigger the processing route
    response = process_audio_from_upload(file_path, filename)

    return response

def process_audio_from_upload(file_path, track_name):
    try:
        logging.info(f"Triggering audio processing for {track_name}")
        
        # Start the stem separation process
        output_dir = f"./stems_output/{track_name}"
        stems_to_process = "two_stems"  # Customize this based on user preference
        process = separate_audio_with_demucs(file_path, stems_to_process, output_dir)

        # Handle the subprocess output (ensure the process completes)
        for line in process.stdout:
            logging.info(f"Demucs output: {line.strip()}")

        process.stdout.close()
        process.wait()

        if process.returncode != 0:
            logging.error(f"Demucs failed with return code {process.returncode}")
            return jsonify({"error": "Demucs processing failed"}), 500

        # Once done, upload the stems to S3
        s3_urls = upload_to_s3(output_dir, track_name)

        return jsonify({
            "message": "Processing completed successfully",
            "stems": s3_urls
        }), 200

    except Exception as e:
        logging.error(f"Error during processing: {e}")
        return jsonify({"error": "Error during processing"}), 500
