# File: engine/api/storage_routes.py
from flask import Blueprint, jsonify
import os
import logging
import shutil
from utils.aws_s3 import s3, AWS_BUCKET_NAME
from botocore.exceptions import NoCredentialsError, ClientError

storage_blueprint = Blueprint('storage', __name__)

# Local file cleanup function
def delete_local_files(directory):
    try:
        if os.path.exists(directory):
            shutil.rmtree(directory)
            logging.info(f"Deleted local files in {directory}")
        else:
            logging.warning(f"Directory {directory} not found for cleanup")
    except Exception as e:
        logging.error(f"Error deleting local files: {str(e)}")

# AWS S3 cleanup function (deletes files in the bucket)
def delete_from_s3(prefix):
    try:
        objects_to_delete = s3.list_objects_v2(Bucket=AWS_BUCKET_NAME, Prefix=prefix)
        if 'Contents' in objects_to_delete:
            delete_keys = [{'Key': obj['Key']} for obj in objects_to_delete['Contents']]
            s3.delete_objects(Bucket=AWS_BUCKET_NAME, Delete={'Objects': delete_keys})
            logging.info(f"Deleted files from S3 with prefix {prefix}")
        else:
            logging.info(f"No files found with prefix {prefix} in S3 bucket {AWS_BUCKET_NAME}")
    except NoCredentialsError:
        logging.error("AWS credentials not available.")
    except ClientError as e:
        logging.error(f"Failed to delete from S3: {e}")
    except Exception as e:
        logging.error(f"Unexpected error deleting from S3: {str(e)}")

# Route to clean up local files after processing
@storage_blueprint.route('/api/cleanup/local-files/<track_name>', methods=['DELETE'])
def cleanup_local(track_name):
    directory = f"./stems_output/{track_name}"
    delete_local_files(directory)
    return jsonify({"message": f"Local files for {track_name} deleted."}), 200

# Route to clean up AWS S3 files after a certain period
@storage_blueprint.route('/api/cleanup/s3-files/<track_name>', methods=['DELETE'])
def cleanup_s3(track_name):
    prefix = f"stems/{track_name}/"
    delete_from_s3(prefix)
    return jsonify({"message": f"S3 files for {track_name} deleted."}), 200
