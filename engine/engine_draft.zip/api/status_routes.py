# File: engine/api/status_routes.py
from flask import Blueprint, jsonify
import logging
import os


status_blueprint = Blueprint('status', __name__)

# In-memory dictionary to store processing status (tracks stems and completion)
processing_status = {}

# Route to fetch the current status of a file being processed
@status_blueprint.route('/api/status/<track_name>', methods=['GET'])
def get_status(track_name):
    if track_name in processing_status:
        status_info = processing_status[track_name]
        logging.info(f"Fetching status for {track_name}: {status_info}")
        return jsonify(status_info), 200
    else:
        logging.error(f"No status found for {track_name}")
        return jsonify({"error": "No status found for this track"}), 404

# Function to initialize and update the status for a track
def initialize_status(track_name, stems):
    processing_status[track_name] = {
        'status': 'processing',
        'current_stem': 'initializing',
        'stems': {stem: 'pending' for stem in stems},
        'error': None
    }

# Function to update the status of a specific stem
def update_stem_status(track_name, stem, status):
    if track_name in processing_status:
        processing_status[track_name]['stems'][stem] = status
        processing_status[track_name]['current_stem'] = stem
        logging.info(f"Updated {stem} status to {status} for {track_name}")

# Function to finalize processing status after all stems are done
def finalize_status(track_name):
    if track_name in processing_status:
        processing_status[track_name]['status'] = 'completed'
        processing_status[track_name]['current_stem'] = 'none'
        logging.info(f"Processing completed for {track_name}")

status_blueprint = Blueprint('status', __name__)

@status_blueprint.route('/api/status/<track_name>', methods=['GET'])
def get_status(track_name):
    # Assuming you're saving stems in `./stems_output/{track_name}`
    stems_directory = f"./stems_output/{track_name}"
    status = "Processing"  # You can add logic to track the real status of the processing

    if os.path.exists(stems_directory):
        stems = [f"/stems_output/{track_name}/{stem}" for stem in os.listdir(stems_directory)]
        status = "Completed"
        return jsonify({"status": status, "stems": stems})

    return jsonify({"status": status}), 200
