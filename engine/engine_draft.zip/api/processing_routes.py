from flask import Blueprint, request, jsonify
from audio_processing.stem_separation import separate_audio_with_demucs
from utils.aws_s3 import upload_to_s3
import logging

processing_blueprint = Blueprint('processing', __name__)

@processing_blueprint.route('/api/process-audio', methods=['POST'])
def process_audio():
    file_path = request.json.get('file_path')
    output_format = request.json.get('format', 'mp3')  # Default to mp3
    track_name = request.json.get('track_name')

    if not file_path:
        logging.error("No file path provided")
        return jsonify({"error": "No file path provided"}), 400

    try:
        logging.info(f"Starting audio separation for {track_name} at {file_path}")
        
        # Start the stem separation
        output_dir = f"./stems_output/{track_name}"
        separate_audio_with_demucs(file_path, output_format, output_dir)

        # Upload separated stems to AWS S3
        s3_urls = upload_to_s3(output_dir, track_name)

        logging.info(f"Processing completed successfully for {track_name}")
        
        return jsonify({
            "message": "Processing completed successfully",
            "stems": s3_urls
        }), 200

    except Exception as e:
        logging.error(f"Error during processing: {str(e)}")
        return jsonify({"error": "Error during processing"}), 500
